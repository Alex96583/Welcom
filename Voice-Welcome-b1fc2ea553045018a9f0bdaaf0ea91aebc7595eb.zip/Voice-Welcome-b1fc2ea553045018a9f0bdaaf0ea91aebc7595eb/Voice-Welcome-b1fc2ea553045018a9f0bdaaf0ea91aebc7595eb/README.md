<p align="center">
  <img src="https://i.pinimg.com/originals/54/19/02/541902f716f7edd427cfa5a9e1230be6.png">  
</p>

<h1 align="center">Termux Voice Welcome - OnlineHacking</h1>
<p align="center">
  Welcome Banner In Termux
</p>

<a href="https://t.me/OnlineHacking"><img src="https://img.shields.io/badge/telegram-Mr.Suman || OnlineHacking-blue.svg">


### MAINTAINERS
* **SUMAN MONDAL**| 
Twitter: <a href="https://twitter.com/suman333mondal">@suman333mondal</a>
Github: <a href="https://github.com/OnlineHacking">@OnlineHacking</a>
Telegram: <a href="https://t.me/OnlineHacking">@OnlineHacking</a>

![unnamed (2)](https://i.pinimg.com/originals/32/9b/50/329b50a3d16e930c39414b1cd32948f7.jpg)

## Video Tutorials

[Video](https://youtu.be/g8GF7n0O_LI)


## Requirements

1. [Termux App](https://play.google.com/store/apps/details?id=com.termux&hl=en_IN)
2. [Termux API App](https://play.google.com/store/apps/details?id=com.termux.api&hl=en_IN)

# ■□■□■□■□■□■□ Commands □■□■□■□■□■□■

### ☣️ Installation and Usage Guide
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ git clone https://github.com/OnlineHacKing/Voice-Welcome.git
```
```
$ cd Voice-Welcome
```
```
$ chmod +x *
```
```
$ sh install.sh
```
Now Type exit & restart Termux

### Update Tool
```
$ rm -rf 'Voice-Welcome' && git clone https://github.com/OnlineHacKing/Voice-Welcome.git && cd Voice-Welcome && sh install.sh && exit
```

## Video Tutorials

[Video](https://youtu.be/g8GF7n0O_LI)

### Subscribe our channel on youtube
https://www.youtube.com/channel/UCwREEQuPIk7EtaRrZBVvDwg?view_as=subscriber&pbjreload=101

### Chekout our webite 
www.onlinehacking-net.cf

# ■□■□■□■□■□■□ Warning □■□■□■□■□■□■

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

***This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool***


# ■□■□■□■□■□■□ Social Media □■□■□■□■□■□■

Website :- http://www.onlinehacking-net.cf

YouTube Channel :- https://bit.ly/on9youtube

Telegram Change :- https://t.me/OnlineHacking

Telegram Group :- https://t.me/OnlineHacking0

Github :- https://github.com/OnlineHacKing

Facebook :-  https://bit.ly/facebook4page

Twitter :- https://bit.ly/twittersuman

Instagram :- https://bit.ly/instagram9oh

<a href="https://t.me/OnlineHacking"><img src="https://img.shields.io/badge/telegram-Ms.Suman || OnlineHacking-blue.svg">


                                       Inspired By github.com/OnlineHacking
